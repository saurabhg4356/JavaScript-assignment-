

function add(num,num2) {
    return num+num2;
}

function subtract(num,num2) {
    return num-num2;
}

function multiply(num,num2) {
    return num*num2;
}

module.exports = {add , subtract , multiply}